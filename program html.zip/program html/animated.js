$(function()
{
    $("h1").slideUp(400);
    $("h1").slideDown(400);
}
)