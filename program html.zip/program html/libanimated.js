



$(function()
{
    $('#div').slideUp(500);
    $('#div').slideDown(500);
   // $('input').hide(500);
   // $('input').show(500);
   // $('input').fadeOut(500);
});

