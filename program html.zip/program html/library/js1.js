$ (function(){
    $("div.box").fadeOut(4000);
)
}