$(function(){
  // $("p").css("background-color","blue");

$("input[type='password']").css("background-color","blue");
$("p:odd").css("background-color","red");
$("p:even").css("background-color","green");

$("input[type='text']").css("background-color","pink");
//$(".a").css("background-color","yellow");
$(".a").find("li").css("background-colour",darkpink);
$(".b").parents("div").css("background-color",lightyellow);

//$("<li>2019 world champion</li>".prependTo($("ul ul:first") ))




});