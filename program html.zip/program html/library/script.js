 /*
$ (function(){
   
$("#cwr1").fadeOut();
$("#Cwr2").fadeOut();
$("#Cwr3").fadeOut();
$("#cwr1").fadeTo(4000,0.2);
$("#Cwr2").fadeToggle(4000);
$("#cwr1").fadeTo(4000,0);
$("#Cwr3").slideUp(4000);
$("#Cwr2").hide(4000);
$("#Cwr2").show(4000);
$("#Cwr3").slideDown();
//....................................................................................
$("#cwr1").animate
(
    {
        "margin-left":"200px",
         "width":"20px",
        "height":"20px",
        "opacity":"0",
        "margin-top":"500px",
        "font-size":"px",
       
    },4000,"swing"
);
$("#Cwr2").animate
(
    {
        "margin-left":"200px",
         "width":"20px",
        "height":"20px",
        "opacity":"0",
        "margin-top":"50px"
    },4000,"swing"
);
$("#Cwr3").animate
(
    {
        "margin-left":"200px",
    },4000,"swing"   
);
$("p").animate(
        { 
            "font-size":"50px",
        }
    );
});
.......................................................................................................................
*/
$ (function(){
//$("#Cwr3").fadeOut(2000);

//$("h2").slideUp(1000);
//$("h2").slideDown(1000);
$("#cwr1").delay(3000).fadeOut(2000);
$("#Cwr2").delay(2000).fadeOut(2000);
$("#Cwr3").delay(4000).fadeOut(2000);
$("#bar").animate(
        { 
            "font-size":"200px",
        }
    );

/*$("p").animate(
        { 
            "font-size":"20px",
        }
    );*/


    });