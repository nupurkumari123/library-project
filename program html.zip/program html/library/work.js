$(function(){

$("h2").toggle();
$("#cot").slideUp(2000);
$("h2").slideDown(5000);
$("#cwr1").delay(3000).fadeOut(2000);
$("#Cwr2").delay(2000).fadeOut(2000);
$("#Cwr3").delay(4000).fadeOut(2000);

 });