$(function (){
    $("#code").load("idontexsit.php",
    function(response,status){
        console.log(response);
       console.log(status);
      if(status === "error" ) {
     alert("could not find idontexist.php");
 }
        
    }

});
});